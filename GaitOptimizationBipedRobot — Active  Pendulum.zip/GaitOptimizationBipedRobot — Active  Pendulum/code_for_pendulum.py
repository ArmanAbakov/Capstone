# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 15:10:39 2025

@author: khmna
"""

import pybullet as p
import pybullet_data
import time
import platform
import numpy as np

# Connect to PyBullet
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())

# Load plane and robot
plane_id = p.loadURDF("plane.urdf")
robot_id = p.loadURDF("nu_biped_final.urdf", basePosition=[0, 0, 0.3], useFixedBase=True)

# Set gravity
p.setGravity(0, 0, -9.81)

# Create real-time sliders for adjusting pendulum angles
roll_slider = p.addUserDebugParameter("Roll Angle", -1.0, 1.0, 0.0)
pitch_slider = p.addUserDebugParameter("Pitch Angle", -1.0, 1.0, 0.0)

#NEW Function to calculate CoM
def calculate_center_of_mass(robot_id):
    total_mass = 0
    weighted_position_sum = np.array([0.0, 0.0, 0.0])
    num_links = p.getNumJoints(robot_id)
    base_mass = p.getDynamicsInfo(robot_id, -1)[0]
    base_pos = np.array(p.getBasePositionAndOrientation(robot_id)[0])
    weighted_position_sum += base_mass * base_pos
    total_mass += base_mass
    for link_id in range(num_links):
        link_mass = p.getDynamicsInfo(robot_id, link_id)[0]
        link_com_world = np.array(p.getLinkState(robot_id, link_id, computeForwardKinematics=True)[0])
        weighted_position_sum += link_mass * link_com_world
        total_mass += link_mass
    return weighted_position_sum / total_mass

# Initialize CoM marker (Sphere)
com = calculate_center_of_mass(robot_id)
com_marker = p.createMultiBody(
    baseMass=0, 
    baseCollisionShapeIndex=p.createCollisionShape(p.GEOM_SPHERE, radius=0.025),
    baseVisualShapeIndex=p.createVisualShape(p.GEOM_SPHERE, radius=0.025, rgbaColor=[1, 0, 1, 1]),
    basePosition=com
)

# Simulation loop
while True:
    roll_angle = p.readUserDebugParameter(roll_slider)
    pitch_angle = p.readUserDebugParameter(pitch_slider)
    
    # Apply new angles to pendulum joints
    p.setJointMotorControl2(robot_id, 12, p.POSITION_CONTROL, targetPosition=roll_angle)
    p.setJointMotorControl2(robot_id, 13, p.POSITION_CONTROL, targetPosition=pitch_angle)
    
    # Recalculate and update CoM
    com = calculate_center_of_mass(robot_id)
    p.resetBasePositionAndOrientation(com_marker, com, [0, 0, 0, 1])  # Move CoM sphere
    
    # Update vertical CoM line
    p.removeAllUserDebugItems()  # Clear old lines
    p.addUserDebugLine(com, [com[0], com[1], 0], [1, 0, 0], 2)  # Draw updated line
    
    p.stepSimulation()
    time.sleep(1.0 / 240.0)
