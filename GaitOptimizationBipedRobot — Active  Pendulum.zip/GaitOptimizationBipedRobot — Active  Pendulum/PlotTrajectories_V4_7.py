#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 13:54:51 2022

@author: folghera
"""
import time
from FootTrajectories import *  
from LinearTrajectory import *   

import numpy as np
import matplotlib.pyplot as plt

PLOT=True
PLOT_ALL=False


# MFX: This function scales the trajectory along the x,y and z axis
# TO DO: you need to invert the -y x z axes for the Asimo trajectories, in a way to match our model, and correct
# this file and OneStep_V4_5 file.This because Asimo own frame is not like oour robot frame.
#Then the scaling will be performed correctly.  

def Scale(rightFootPathData,leftFootPathData,scale_f=[1,1,1]):
    New_rightFootPathData=[]
    New_leftFootPathData=[]

    # To Do
    for i in range (0,len(rightFootPathData)-7,7): 
        New_rightFootPathData.append(rightFootPathData[i]*scale_f[0])#ASSIMETRY
        New_rightFootPathData.append(rightFootPathData[i+1]*scale_f[1])
        New_rightFootPathData.append(rightFootPathData[i+2]*scale_f[2])
        New_rightFootPathData.append(rightFootPathData[i+3])
        New_rightFootPathData.append(rightFootPathData[i+4])
        New_rightFootPathData.append(rightFootPathData[i+5])
        New_rightFootPathData.append(rightFootPathData[i+6])
        
    for i in range (0,len(leftFootPathData)-7,7): 
        New_leftFootPathData.append(leftFootPathData[i]*scale_f[0]) 
        New_leftFootPathData.append(leftFootPathData[i+1]*scale_f[1])  
        New_leftFootPathData.append(leftFootPathData[i+2]*scale_f[2])
        New_leftFootPathData.append(leftFootPathData[i+3])
        New_leftFootPathData.append(leftFootPathData[i+4])
        New_leftFootPathData.append(leftFootPathData[i+5])
        New_leftFootPathData.append(leftFootPathData[i+6])
    
    
    return(New_rightFootPathData,New_leftFootPathData)
            
def ChangeDistance(rightFootPathData,leftFootPathData,distance=0):
    New_rightFootPathData=[]
    New_leftFootPathData=[]
    # To Do
    for i in range (0,len(rightFootPathData)-7,7): 
        New_rightFootPathData.append(rightFootPathData[i]-distance/2)
        New_rightFootPathData.append(rightFootPathData[i+1])
        New_rightFootPathData.append(rightFootPathData[i+2])
        New_rightFootPathData.append(rightFootPathData[i+3])
        New_rightFootPathData.append(rightFootPathData[i+4])
        New_rightFootPathData.append(rightFootPathData[i+5])
        New_rightFootPathData.append(rightFootPathData[i+6])
        
    for i in range (0,len(leftFootPathData)-7,7): 
        New_leftFootPathData.append(leftFootPathData[i]+distance/2)
        New_leftFootPathData.append(leftFootPathData[i+1])
        New_leftFootPathData.append(leftFootPathData[i+2])
        New_leftFootPathData.append(leftFootPathData[i+3])
        New_leftFootPathData.append(leftFootPathData[i+4])
        New_leftFootPathData.append(leftFootPathData[i+5])
        New_leftFootPathData.append(leftFootPathData[i+6])
        
    return(New_rightFootPathData,New_leftFootPathData)


            
def quaternion_rotation_matrix(Q):
    """
    Covert a quaternion into a full three-dimensional rotation matrix.
 
    Input
    :param Q: A 4 element array representing the quaternion (q0,q1,q2,q3) 
 
    Output
    :return: A 3x3 element matrix representing the full 3D rotation matrix. 
             This rotation matrix converts a point in the local reference 
             frame to a point in the global reference frame.
    """
    # Extract the values from Q
    q0 = Q[0]
    q1 = Q[1]
    q2 = Q[2]
    q3 = Q[3]
     
    # First row of the rotation matrix
    r00 = 2 * (q0 * q0 + q1 * q1) - 1
    r01 = 2 * (q1 * q2 - q0 * q3)
    r02 = 2 * (q1 * q3 + q0 * q2)
     
    # Second row of the rotation matrix
    r10 = 2 * (q1 * q2 + q0 * q3)
    r11 = 2 * (q0 * q0 + q2 * q2) - 1
    r12 = 2 * (q2 * q3 - q0 * q1)
     
    # Third row of the rotation matrix
    r20 = 2 * (q1 * q3 - q0 * q2)
    r21 = 2 * (q2 * q3 + q0 * q1)
    r22 = 2 * (q0 * q0 + q3 * q3) - 1
     
    # 3x3 rotation matrix
    rot_matrix = np.array([[r00, r01, r02],
                           [r10, r11, r12],
                           [r20, r21, r22]])
                            
    return r00,r10,r20,r01,r11,r21,r02,r12,r22


def PlotFeetTrajectory(rightFootPathData,leftFootPathData, l2=0):
    PositionR=[]
    PositionL=[]

    for i in range(int(len(leftFootPathData)/7)):
               # print(times[i])
                coord = rightFootPathData[7 * i:7 * i + 7]
                coord2 = leftFootPathData[7 * i:7 * i + 7]
        
                Q = coord[3:7]
                px = -coord[1]  
                py = coord[0]-l2
                pz = TotScalingZ*coord[2]
                
                PositionR.append([px,py,pz])

                Q2 = coord2[3:7]
                px2 = -coord2[1]
                py2 = coord2[0]+l2
                pz2 = coord2[2]
                PositionL.append([px2,py2,pz2])
                
     
                

    PositionR=np.array(PositionR)
    PositionL=np.array(PositionL)
    
    fig = plt.figure()
    ax = plt.axes(projection='3d')
    
    # RIGHT FOOT Blue
    x_line=PositionR[:,0]
    y_line=PositionR[:,1]
    z_line=PositionR[:,2]
    
    
    ax.plot3D(x_line, y_line, z_line, 'blue')
    
    # LEFT FOOT red
    
    x_line2=PositionL[:,0]
    y_line2=PositionL[:,1]
    z_line2=PositionL[:,2]
    
    ax.view_init(elev=20, azim=30)
    ax.plot3D(x_line2, y_line2, z_line2, 'red')
    
    lim=0.5
    
    ax.set_xlim(-lim,lim)
    ax.set_ylim(-lim,lim)
    ax.set_zlim(0,lim)
    ax.set_xlabel("X [m]")
    ax.set_ylabel("Y [m]")
    ax.set_zlabel("Z [m]")
    fig.tight_layout()

#Load the Step Trajectory

# Scale the Cartesian Trajectory
rightFootPathData,leftFootPathData=Scale(rightFootPathData, leftFootPathData,[1,1,1])

# Change the feet trajectories according to the distance between the feet (meters)

rightFootPathData,leftFootPathData=ChangeDistance(rightFootPathData, leftFootPathData,0)

PositionR=[]
PositionL=[]

for i in range(int(len(leftFootPathData)/7)):
           # print(times[i])
            coord = rightFootPathData[7 * i:7 * i + 7]
            coord2 = leftFootPathData[7 * i:7 * i + 7]
            #coord2 = LinearTrajectory[7 * i:7 * i + 7]
            #print("quat:",coord[3:7])
            #print("x,y,z:", coord[0:3])
            
            # Each data row includes 7 elements, the first three reporesent the positin (x,y,z) the last four are the lements of a quaternion
            # that represent the orienation of the foot frame.
            TotScalingY=1
            TotScalingX=1
            TotScalingZ=1
            
            # Real Robot Mesasuraments NU_Biped V4
            #l2 = 0.232
             # Real Robot Mesasuraments NU_Biped V4.5
            l2 = 0.180
            #l2=0
            Q = coord[3:7]
            px = -coord[1]*TotScalingX    
            py = TotScalingY*(coord[0])-l2
            pz = TotScalingZ*coord[2]
            
            PositionR.append([px,py,pz])

            Q2 = coord2[3:7]
            px2 = -coord2[1]*TotScalingX 
            py2 = TotScalingY*coord2[0]+l2
            pz2 = TotScalingZ*coord2[2]
            # print("pz=",pz)
            
            
            PositionL.append([px2,py2,pz2])
            
            # print("pz=",pz)
            

PositionR=np.array(PositionR)
PositionL=np.array(PositionL)



if PLOT:
    # fig = plt.figure()



    fig = plt.figure()
    ax = plt.axes(projection='3d')
    
    
    # Data for a three-dimensional line
    
    
    # RIGHT FOOT Blue
    x_line=PositionR[:,0]
    y_line=PositionR[:,1]
    z_line=PositionR[:,2]
    
    
    ax.plot3D(x_line, y_line, z_line, 'blue')
    
    # LEFT FOOT red
    
    x_line2=PositionL[:,0]
    y_line2=PositionL[:,1]
    z_line2=PositionL[:,2]
    
    ax.view_init(elev=20, azim=30)
    ax.plot3D(x_line2, y_line2, z_line2, 'red')
    
    lim=0.5
    
    ax.set_xlim(-lim,lim)
    ax.set_ylim(-lim,lim)
    ax.set_zlim(0,lim)
    ax.set_xlabel("X [m]")
    ax.set_ylabel("Y [m]")
    ax.set_zlabel("Z [m]")
    fig.tight_layout()

    if (PLOT_ALL):
    
        fig, ax = plt.subplots(figsize=(5, 5))
        fig.subplots_adjust(bottom=0.2, left=0.2) 
        ax.plot(x_line2, z_line2,color = 'black')
        ax.set_title(' Projection in X-Z')
        ax.set_xlabel('X [m]') 
        ax.set_ylabel('Z [m]')
        
    
        fig.tight_layout()
    
    
        plt.show()
        
    
    
    
        fig, ax = plt.subplots(figsize=(5, 5))
        fig.subplots_adjust(bottom=0.2, left=0.2)
        ax.plot(x_line2, y_line2,color = 'black')
        ax.set_title(' Projection in X-Y')
        ax.set_xlabel('X [m]')
        ax.set_ylabel('Y [m]')
        fig.tight_layout()
    
        plt.show()
    
    
    
        fig, ax = plt.subplots(figsize=(5, 5))
        #fig.subplots_adjust(bottom=0.2, left=0.2)
        ax.plot(y_line2, z_line2,color = 'black')
        ax.set_title(' Projection in Y-Z')
        ax.set_xlabel('Y [m]')
        ax.set_ylabel('Z [m]')
        fig.tight_layout()
    
    
        plt.show()





            
