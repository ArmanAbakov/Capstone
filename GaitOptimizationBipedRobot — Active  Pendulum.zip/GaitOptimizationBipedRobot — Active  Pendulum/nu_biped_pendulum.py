import pybullet_data
import time
import platform
import pybullet as p
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

plt.style.use('MFX_Plot.mplstyle')

joint_controls = [
    {"joint_id": 0, "scale": 1.0},
    {"joint_id": 1, "scale": 1.0},
    {"joint_id": 2, "scale": 1.0},
    {"joint_id": 3, "scale": 1.0},
    {"joint_id": 4, "scale": 1.0},
    {"joint_id": 5, "scale": 1.0},
    {"joint_id": 6, "scale": 1.0},
    {"joint_id": 7, "scale": 1.0},
    {"joint_id": 8, "scale": 1.0},
    {"joint_id": 9, "scale": 1.0},
    {"joint_id": 10, "scale": 1.0},
    {"joint_id": 11, "scale": 1.0},
    {"joint_id": 12, "scale": 1.0},
    {"joint_id": 13, "scale": 1.0},
    ]

# Define joint control function
def control_joints(robot_id, target_positions):
    # Ensure target_positions matches the number of joint_controls
    if len(target_positions) != len(joint_controls):
        raise ValueError("The number of target_positions must match the number of joint_controls.")

    # Iterate through joint_controls and assign target positions
    for i, control in enumerate(joint_controls):
        p.setJointMotorControl2(
            bodyUniqueId=robot_id,
            jointIndex=control["joint_id"],
            controlMode=p.POSITION_CONTROL,
            targetPosition=target_positions[i],  # Assign target position for each joint
            force=100  # Maximum torque applied
        )



def calculate_total_weight(robot_id):
    """
    Calculate the total weight of the robot by summing the masses of all links and the base.
    """
    total_mass = 0.0

    # Get the number of links (including the base link at -1)
    num_links = p.getNumJoints(robot_id)

    # Include the base link (index -1)
    base_dynamics = p.getDynamicsInfo(robot_id, -1)  # Get base link dynamics
    base_mass = base_dynamics[0]  # Mass of the base link
    print(f"Mass of the base link of the robot: {base_mass:.3f} kg")
    total_mass += base_mass

    # Iterate through all the links (from 0 to num_links-1)
    for link_id in range(num_links):
        link_dynamics = p.getDynamicsInfo(robot_id, link_id)  # Get link dynamics
        link_mass = link_dynamics[0]  # Mass of the link
        link_name = p.getJointInfo(robot_id, link_id)[12].decode("utf-8")
        print(f"Link {link_id}: {link_name}, Mass = {link_mass:.2f}")
        total_mass += link_mass

    return total_mass


if platform.system() == 'Windows':
    physics_client = p.connect(p.GUI)
else:
    # Connect to PyBullet and set up the environment
    screen_width = 1920
    screen_height = 1080
    physics_client = p.connect(p.GUI, options=f"--width={screen_width} --height={screen_height}")  # Use p.DIRECT for headless simulation

p.setAdditionalSearchPath(pybullet_data.getDataPath())  # For plane and other default resources

# Set the camera closer to the robot
camera_distance = 1.5  # Distance from the robot
camera_yaw = 55      # Angle around the robot
camera_pitch = -40   # Angle above the robot
camera_target = [0, 0, 1.0]  # Focus point (robot's torso)

p.resetDebugVisualizerCamera(
    cameraDistance=camera_distance,
    cameraYaw=camera_yaw,
    cameraPitch=camera_pitch,
    cameraTargetPosition=camera_target
)


# Load the ground plane
plane_id = p.loadURDF("plane.urdf")
startOrientation = p.getQuaternionFromEuler([0,0,0])

# Load the humanoid URDF file
robot_id = p.loadURDF("nu_biped_final.urdf", basePosition=[0, 0, 0.3], useFixedBase=True)

# Set gravity
p.setGravity(0, 0, -9.81)

# Simulation parameters
time_step = 1.0 / 240.0  # Simulation time step
p.setTimeStep(time_step)
p.setRealTimeSimulation(0)  # Disable real-time simulation for better control

# Create the slider
# slider_id = p.addUserDebugParameter("dummy_data", 3, 5, 4)

#NEW Create real-time sliders for adjusting pendulum angles
roll_slider = p.addUserDebugParameter("Roll Angle", -1.0, 1.0, 0.0)
pitch_slider = p.addUserDebugParameter("Pitch Angle", -1.0, 1.0, 0.0)


# JointHandle
JointNames = ["LHipYaw", "LHipPitch", "LHipRoll", "LKnee", "LAnklePitch", "LAnkleRoll",
              "RHipYaw", "RHipPitch", "RHipRoll", "RKnee", "RAnklePitch", "RAnkleRoll"]
JointHandles = {"LHipYaw": 0, "LHipPitch": 1, "LHipRoll": 2, "LKnee": 3, "LAnklePitch": 4, "LAnkleRoll": 5,
                "RHipYaw": 6, "RHipPitch": 7, "RHipRoll": 8, "RKnee": 9, "RAnklePitch": 10, "RAnkleRoll": 11}
HomeJointPositions = {"LHipYaw": 0, "LHipPitch": 0, "LHipRoll": 0, "LKnee": 0, "LAnklePitch": 0, "LAnkleRoll": 0,
                      "RHipYaw": 0, "RHipPitch": 0, "RHipRoll": 0, "RKnee": 0, "RAnklePitch": 0, "RAnkleRoll": 0}


# Get the number of joints and joint info
num_joints = p.getNumJoints(robot_id)
print(f"Number of joints: {num_joints}")
for joint_id in range(num_joints):
    joint_info = p.getJointInfo(robot_id, joint_id)
    print(f"Joint {joint_id}: Name={joint_info[1].decode('utf-8')}, Type={joint_info[2]}")

angle_deg = 30
angle_rad = np.deg2rad(angle_deg)

joint_positions = [angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0,
                   angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0, angle_rad * 0.0,
                   angle_rad * 0.0, angle_rad * 0.0]




#NEW Function to calculate CoM
def calculate_center_of_mass(robot_id):
    total_mass = 0
    weighted_position_sum = np.array([0.0, 0.0, 0.0])
    num_links = p.getNumJoints(robot_id)
    base_mass = p.getDynamicsInfo(robot_id, -1)[0]
    base_pos = np.array(p.getBasePositionAndOrientation(robot_id)[0])
    weighted_position_sum += base_mass * base_pos
    total_mass += base_mass
    for link_id in range(num_links):
        link_mass = p.getDynamicsInfo(robot_id, link_id)[0]
        link_com_world = np.array(p.getLinkState(robot_id, link_id, computeForwardKinematics=True)[0])
        weighted_position_sum += link_mass * link_com_world
        total_mass += link_mass
    return weighted_position_sum / total_mass

# Initialize CoM marker (Sphere)
com = calculate_center_of_mass(robot_id)
com_marker = p.createMultiBody(
    baseMass=0, 
    baseCollisionShapeIndex=p.createCollisionShape(p.GEOM_SPHERE, radius=0.025),
    baseVisualShapeIndex=p.createVisualShape(p.GEOM_SPHERE, radius=0.025, rgbaColor=[1, 0, 1, 1]),
    basePosition=com
)

# Simulation loop with error handling
try:
    while True:
        roll_angle = p.readUserDebugParameter(roll_slider)
        pitch_angle = p.readUserDebugParameter(pitch_slider)
        
        # Apply new angles to pendulum joints
        p.setJointMotorControl2(robot_id, 12, p.POSITION_CONTROL, targetPosition=roll_angle)
        p.setJointMotorControl2(robot_id, 13, p.POSITION_CONTROL, targetPosition=pitch_angle)
        
        # Recalculate and update CoM
        com = calculate_center_of_mass(robot_id)
        p.resetBasePositionAndOrientation(com_marker, com, [0, 0, 0, 1])  # Move CoM sphere
        
        # Update vertical CoM line
        p.removeAllUserDebugItems()  # Clear old lines
        p.addUserDebugLine(com, [com[0], com[1], 0], [1, 0, 0], 2)  # Draw updated line
        
        p.stepSimulation()
        time.sleep(1.0 / 240.0)
except KeyboardInterrupt:
    print("Simulation terminated by user.")
    p.disconnect()
