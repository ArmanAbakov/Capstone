#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 22 12:03:34 2022

@author: folghera
"""
import numpy as np
import math


def atan2d(x, y):

    result = math.degrees(math.atan2(x, y))

    return result
    # the sind(x) function computes the sine of an angle x expressed in degrees


def sind(x):

    result = math.sin(math.radians(x))

    if abs(result) <= math.pi * 1e-16:
        result = 0

    return result
    # the cosd(x) function computes the cosine of the angle x expressed in degrees


def cosd(x):

    result = math.cos(math.radians(x))

    if abs(result) <= math.pi * 1e-16:
        result = 0

    return result
    # the function tand(x) is a function that computes the tangent of the angle x expressed in degrees


def tand(x):

    result = math.tan(math.radians(x))

    if abs(result) <= math.pi * 1e-16:
        result = 0

    return result
    # this is the function that computes the angles of the joints of the
    # robot for a given position and orientation of the ankle relative to the
    # hip


def quaternion_rotation_matrix(Q):
    """
    Covert a quaternion into a full three-dimensional rotation matrix.

    Input
    :param Q: A 4 element array representing the quaternion (q0,q1,q2,q3)

    Output
    :return: A 3x3 element matrix representing the full 3D rotation matrix.
             This rotation matrix converts a point in the local reference
             frame to a point in the global reference frame.
    """
    # Extract the values from Q
    q0 = Q[3]
    q1 = Q[0]
    q2 = Q[1]
    q3 = Q[2]

    # vx = -(2 * (q0 * q0 + q1 * q1) - 1)
    # ux = (2 * (q1 * q2 - q0 * q3))
    # wx = 2 * (q1 * q3 + q0 * q2)
    #
    # # Second row of the rotation matrix
    # vy = 2 * (q1 * q2 + q0 * q3)
    # uy = 2 * (q0 * q0 + q2 * q2) - 1
    # wy = 2 * (q2 * q3 - q0 * q1)
    #
    # # Third row of the rotation matrix
    # vz = 2 * (q1 * q3 - q0 * q2)
    # uz = 2 * (q2 * q3 + q0 * q1)
    # wz = 2 * (q0 * q0 + q3 * q3) - 1
    # First row of the rotation matrix
    ux = (2 * (q0 * q0 + q1 * q1) - 1)
    vx = 2 * (q1 * q2 - q0 * q3)
    wx = 2 * (q1 * q3 + q0 * q2)

    # Second row of the rotation matrix
    uy = 2 * (q1 * q2 + q0 * q3)
    vy = 2 * (q0 * q0 + q2 * q2) - 1
    wy = 2 * (q2 * q3 - q0 * q1)

    # Third row of the rotation matrix
    uz = 2 * (q1 * q3 - q0 * q2)
    vz = 2 * (q2 * q3 + q0 * q1)
    wz = 2 * (q0 * q0 + q3 * q3) - 1

    # 3x3 rotation matrix
    rot_matrix = np.array([[ux, vx, wx],
                           [uy, vy, wy],
                           [uz, vz, wz]])

    # rot_matrix = np.array([r00,r10,r20,r01,r11,r21,r02,r12,r22])

    #print(rot_matrix)
    #print('\n')
    return ux, uy, uz, vx, vy, vz, wx, wy, wz




def ik_method(px, py, pz, ux, uy, uz, vx, vy, vz, wx, wy, wz, Print=False):

    # l1 = 0.2515
    # l2 = 0.232 
    # l3 = 0.3849
    # l4 = 0.268
    # l5 = 0.0752
    # l6 = 0.1119
    
    # #MFX
    # #Target pose with respect to frame1
    # T_one=np.array([[ux,vx,wx,px],[uy,vy,wy,py],[uz,vz,wz,pz],[0,0,0,1]])
    
    # print("T_one",T_one)
    # #Target pose with respect to frame{u,v,w} 
    # T_uvw=np.linalg.inv(T_one)
    
    # print("T_uvw",T_uvw)
    
    
    # Identity=np.matmul(T_one,T_uvw)
    # print("Identity",Identity)
    
    # ux=T_uvw[0,0]
    # vx=T_uvw[0,1]
    # wx=T_uvw[0,2]
    # px=T_uvw[0,3]
    
    # uy=T_uvw[1,0]
    # vy=T_uvw[1,1]
    # wy=T_uvw[1,2]
    # py=T_uvw[1,3]
    
    # uz=T_uvw[2,0]
    # vz=T_uvw[2,1]
    # wz=T_uvw[2,2]
    # pz=T_uvw[2,3]
    
    
    
    # Correct Dimensions Real Robot
    l1 = 0.166
    l2 = 0.232 
    l3 = 0.366
    l4 = 0.260
    l5 = 0.104
    l6 = 0.134
    
    
    lz = l3 + l4 + l5 + l6

    # l1 = 0.2515
    # l2 = 0.2675
    # l3 = 0.3594
    # l4 = 0.268
    # l5 = 0.075
    # l6 = 0.1124


    # these conditions are used for checking whether or not l3 * cos(t4 + t5) +
    # l4 * cos(t5) < 0, which would mean that we should add pi to t6
    cond1 = False
    cond2 = False
    cond3 = False
    cond4 = False

    # then we calculate t6
    t6 = atan2d(-py, (-l6 + pz))
    # t6 = math.atan(-py / (-l6 + pz))
    
    if(Print):
        print("t6=", t6)
        
    lz = l3 + l4 + l5 + l6
    #print("lz=", lz)
    # this is for calculating t4
    # we have two values for t4 because we know that we can have two signs for
    # the square root of 1 - cos(t4)^2
    # c4 stands for cos(t4)
    c4 = (px ** 2 + (-py - sind(t6) * l5) ** 2 + (pz - l6 - cosd(t6) * l5) ** 2 - l3 ** 2 - l4 ** 2) / (
            2 * l3 * l4)
    
    # MFX    
    if (c4>1):
        c4=0.99

    if (Print):
        print("c4=",c4)
    


    
    t41 = atan2d(math.sqrt(1 - c4 ** 2), c4)
    t42 = atan2d(-math.sqrt(1 - c4 ** 2), c4)

    # the code below is for calculating t5
    # we have 4 values for t5 since we have two signs for the square root
    # of px^2 + py^2, and we have two values for gamma
    # which is the angle atan2(l3 * s4, l3 * c4 + l4)
    gamma1 = atan2d(l3 * sind(t41), l3 * cosd(t41) + l4)
    gamma2 = atan2d(l3 * sind(t42), l3 * cosd(t42) + l4)
    t51 = atan2d(px, math.sqrt((pz - l6 - cosd(t6) * l5) ** 2 + (-py - sind(t6) * l5) ** 2)) - gamma1
    t52 = atan2d(px, math.sqrt((pz - l6 - cosd(t6) * l5) ** 2 + (-py - sind(t6) * l5) ** 2)) - gamma2
    t53 = atan2d(px, -math.sqrt((pz - l6 - cosd(t6) * l5) ** 2 + (-py - sind(t6) * l5) ** 2)) - gamma1
    t54 = atan2d(px, -math.sqrt((pz - l6 - cosd(t6) * l5) ** 2 + (-py - sind(t6) * l5) ** 2)) - gamma2

    # the below code is for calculating t1 and t3
    # we first check if we need to add pi to t6
    # and depending on whether we do or not, we calculate t1 and t3
    # using the original t6 or t6 + 180
    # we have 4 values of t1 and t3 for the pairs (t41,t51),(t42,t52),(t41,t53)
    # (t42,t54) for the case where we need to use the original t6
    # and another four for the case where we need to add pi to the original t6
    if l3 * cosd(t41 + t51) + l4 * cosd(t51) < 0:

        t61 = t6 + 180
        cond1 = True

        t11 = atan2d(
            +vz * cosd(t61) * sind(t41 + t51) - vy * sind(t61) * sind(t41 + t51) - vx * cosd(t41 + t51), \
            -uz * cosd(t61) * sind(t41 + t51) + uy * sind(t61) * sind(t41 + t51) + ux * cosd(t41 + t51))

        t31 = atan2d(-wy * cosd(t61) - wz * sind(t61), wz * cosd(t41 + t51) * cosd(t61) + \
                     wx * sind(t41 + t51) - wy * cosd(t41 + t51) * sind(t61))

    else:

        t11 = atan2d(+vz * cosd(t6) * sind(t41 + t51) - vy * sind(t6) * sind(t41 + t51) - vx * cosd(t41 + t51), \
                     -uz * cosd(t6) * sind(t41 + t51) + uy * sind(t6) * sind(t41 + t51) + ux * cosd(t41 + t51))

        t31 = atan2d(-wy * cosd(t6) - wz * sind(t6), wz * cosd(t41 + t51) * cosd(t6) + \
                     wx * sind(t41 + t51) - wy * cosd(t41 + t51) * sind(t6))

    if l3 * cosd(t42 + t52) + l4 * cosd(t52) < 0:

        t62 = t6 + 180
        cond2 = True

        t12 = atan2d(
            +vz * cosd(t62) * sind(t42 + t52) - vy * sind(t62) * sind(t42 + t52) - vx * cosd(t42 + t52), \
            -uz * cosd(t62) * sind(t42 + t52) + uy * sind(t62) * sind(t42 + t52) + ux * cosd(t42 + t52))

        t32 = atan2d(-wy * cosd(t62) - wz * sind(t62), wz * cosd(t42 + t52) * cosd(t62) + \
                     wx * sind(t42 + t52) - wy * cosd(t42 + t52) * sind(t62))

    else:

        t12 = atan2d(+vz * cosd(t6) * sind(t42 + t52) - vy * sind(t6) * sind(t42 + t52) - vx * cosd(t42 + t52), \
                     -uz * cosd(t6) * sind(t42 + t52) + uy * sind(t6) * sind(t42 + t52) + ux * cosd(t42 + t52))

        t32 = atan2d(-wy * cosd(t6) - wz * sind(t6), wz * cosd(t42 + t52) * cosd(t6) + \
                     wx * sind(t42 + t52) - wy * cosd(t42 + t52) * sind(t6))

    if l3 * cosd(t41 + t53) + l4 * cosd(t53) < 0:

        t63 = t6 + 180
        cond3 = True

        t13 = atan2d(
            +vz * cosd(t63) * sind(t41 + t53) - vy * sind(t63) * sind(t41 + t53) - vx * cosd(t41 + t53), \
            -uz * cosd(t63) * sind(t41 + t53) + uy * sind(t63) * sind(t41 + t53) + ux * cosd(t41 + t53))

        t33 = atan2d(-wy * cosd(t63) - wz * sind(t63), wz * cosd(t41 + t53) * cosd(t63) + \
                     wx * sind(t41 + t53) - wy * cosd(t41 + t53) * sind(t63))

    else:

        t13 = atan2d(+vz * cosd(t6) * sind(t41 + t53) - vy * sind(t6) * sind(t41 + t53) - vx * cosd(t41 + t53), \
                     -uz * cosd(t6) * sind(t41 + t53) + uy * sind(t6) * sind(t41 + t53) + ux * cosd(t41 + t53))

        t33 = atan2d(-wy * cosd(t6) - wz * sind(t6), wz * cosd(t41 + t53) * cosd(t6) + \
                     wx * sind(t41 + t53) - wy * cosd(t41 + t53) * sind(t6))

    if l3 * cosd(t42 + t54) + l4 * cosd(t54) < 0:

        t64 = t6 + 180
        cond4 = True

        t14 = atan2d(
            +vz * cosd(t64) * sind(t42 + t54) - vy * sind(t64) * sind(t42 + t54) - vx * cosd(t42 + t54), \
            -uz * cosd(t64) * sind(t42 + t54) + uy * sind(t64) * sind(t42 + t54) + ux * cosd(t42 + t54))

        t34 = atan2d(-wy * cosd(t64) - wz * sind(t64), wz * cosd(t42 + t54) * cosd(t64) + \
                     wx * sind(t42 + t54) - wy * cosd(t42 + t54) * sind(t64))

    else:

        t14 = atan2d(+vz * cosd(t6) * sind(t42 + t54) - vy * sind(t6) * sind(t42 + t54) - vx * cosd(t42 + t54), \
                     -uz * cosd(t6) * sind(t42 + t54) + uy * sind(t6) * sind(t42 + t54) + ux * cosd(t42 + t54))

        t34 = atan2d(-wy * cosd(t6) - wz * sind(t6), wz * cosd(t42 + t54) * cosd(t6) + \
                     wx * sind(t42 + t54) - wy * cosd(t42 + t54) * sind(t6))

    # the below code is for calculating t2
    # since we are dividing by sin(t1), we need to first check if it's not 0
    # if it is, we us a modified formula for t2
    # we have 4 values of t2 for the pairs (t41,t51),(t42,t52),(t41,t53)
    # (t42,t54) for the case where sin(t1) != 0 and 4 more for the case
    # where sin(t1) == 0
    if cond1 == True:

        if sind(t31) != 0:

            t21 = atan2d(
                -wz * cosd(t61) * sind(t41 + t51) + wy * sind(t61) * sind(t41 + t51) + wx * cosd(t41 + t51), \
                (-wy * cosd(t61) - wz * sind(t61)) / (sind(t31)))

        else:

            t21 = atan2d(
                -wz * cosd(t61) * sind(t41 + t51) + wy * sind(t61) * sind(t41 + t51) + wx * cosd(t41 + t51), \
                (wx * sind(t41 + t51) - wy * sind(t61) * cosd(t41 + t51) + wz * cosd(t61) * cosd(t41 + t51)) / (
                    cosd(t31)))


    else:

        if sind(t31) != 0:

            t21 = atan2d(
                -wz * cosd(t6) * sind(t41 + t51) + wy * sind(t6) * sind(t41 + t51) + wx * cosd(t41 + t51), \
                (-wy * cosd(t6) - wz * sind(t6)) / (sind(t31)))

        else:

            t21 = atan2d(
                -wz * cosd(t6) * sind(t41 + t51) + wy * sind(t6) * sind(t41 + t51) + wx * cosd(t41 + t51), \
                (wx * sind(t41 + t51) - wy * sind(t6) * cosd(t41 + t51) + wz * cosd(t6) * cosd(
                    t41 + t51)) / cosd(t31))

    if cond2 == True:

        if sind(t32) != 0:

            t22 = atan2d(
                -wz * cosd(t62) * sind(t42 + t52) + wy * sind(t62) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (-wy * cosd(t62) - wz * sind(t62)) / (sind(t32)))

        else:

            t22 = atan2d(
                -wz * cosd(t62) * sind(t42 + t52) + wy * sind(t62) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (wx * sind(t42 + t52) - wy * sind(t62) * cosd(t42 + t52) + wz * cosd(t62) * cosd(
                    t42 + t52)) / cosd(t32))


    else:

        if sind(t32) != 0:

            t22 = atan2d(
                -wz * cosd(t6) * sind(t42 + t52) + wy * sind(t6) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (-wy * cosd(t6) - wz * sind(t6)) / (sind(t32)))

        else:

            t22 = atan2d(
                -wz * cosd(t6) * sind(t42 + t52) + wy * sind(t6) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (wx * sind(t42 + t52) - wy * sind(t6) * cosd(t42 + t52) + wz * cosd(t6) * cosd(
                    t42 + t52)) / cosd(t32))

    if cond3 == True:

        if sind(t33) != 0:

            t23 = atan2d(
                -wz * cosd(t63) * sind(t41 + t53) + wy * sind(t63) * sind(t41 + t53) + wx * cosd(t41 + t53), \
                (-wy * cosd(t63) - wz * sind(t63)) / (sind(t33)))
        else:

            t23 = atan2d(
                -wz * cosd(t63) * sind(t41 + t53) + wy * sind(t63) * sind(t41 + t53) + wx * cosd(t41 + t53), \
                (wx * sind(t41 + t53) - wy * sind(t63) * cosd(t41 + t53) + wz * cosd(t63) * cosd(
                    t41 + t53)) / cosd(t33))


    else:

        if sind(t33) != 0:

            t23 = atan2d(
                -wz * cosd(t6) * sind(t41 + t53) + wy * sind(t6) * sind(t41 + t53) + wx * cosd(t41 + t53), \
                (-wy * cosd(t6) - wz * sind(t6)) / (sind(t33)))

        else:

            t23 = atan2d(
                -wz * cosd(t6) * sind(t41 + t53) + wy * sind(t6) * sind(t41 + t53) + wx * cosd(t41 + t53), \
                (wx * sind(t41 + t53) - wy * sind(t6) * cosd(t41 + t53) + wz * cosd(t6) * cosd(
                    t41 + t53)) / cosd(t33))

    if cond4 == True:

        if sind(t34) != 0:

            t24 = atan2d(
                -wz * cosd(t64) * sind(t42 + t52) + wy * sind(t64) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (-wy * cosd(t64) - wz * sind(t64)) / (sind(t34)))
        else:

            t24 = atan2d(
                -wz * cosd(t64) * sind(t42 + t52) + wy * sind(t64) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (wx * sind(t42 + t52) - wy * sind(t64) * cosd(t42 + t52) + wz * cosd(t64) * cosd(
                    t42 + t52)) / cosd(t34))


    else:

        if sind(t34) != 0:

            t24 = atan2d(
                -wz * cosd(t6) * sind(t42 + t52) + wy * sind(t6) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (-wy * cosd(t6) - wz * sind(t6)) / (sind(t34)))

        else:

            t24 = atan2d(
                -wz * cosd(t6) * sind(t42 + t52) + wy * sind(t6) * sind(t42 + t52) + wx * cosd(t42 + t52), \
                (wx * sind(t42 + t52) - wy * sind(t6) * cosd(t42 + t52) + wz * cosd(t6) * cosd(
                    t42 + t52)) / cosd(t34))

    # print("t11 = ", t11)
    # print("t12 = ", t12)
    # print("t13 = ", t13)
    # print("t14 = ", t14)
    # print("")
    # print("t21 = ", t21)
    # print("t22 = ", t22)
    # print("t23 = ", t23)
    # print("t24 = ", t24)
    # print("")
    # print("t31 = ", t31)
    # print("t32 = ", t32)
    # print("t33 = ", t33)
    # print("t34 = ", t34)
    # print("")
    # print("t41 = ", t41)
    # print("t42 = ", t42)
    # print("")
    # print("t51 = ", t51)
    # print("t52 = ", t52)
    # print("t53 = ", t53)
    # print("t54 = ", t54)
    # print("")
    # print("t6 = ", t6)



    return np.array([t11, t21, t31, t41, t51, t6])


