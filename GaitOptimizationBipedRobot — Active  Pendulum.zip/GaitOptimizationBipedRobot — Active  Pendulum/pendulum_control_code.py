# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 13:37:44 2025

@author: khmnaz
"""
import pybullet as p
import pybullet_data
import time
import numpy as np
import matplotlib.pyplot as plt

# Connect to PyBullet
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -9.81)

# Load ground plane
plane_id = p.loadURDF("plane.urdf")

# Load robot
robot_id = p.loadURDF("nu_biped_final.urdf", [0, 0, 1])

# Get number of joints
num_joints = p.getNumJoints(robot_id)

# Define the roll and pitch joints for the pendulum
roll_joint = 12  # Adjust based on your URDF
pitch_joint = 13

# Define hip yaw joints (acting as torso fix points)
Rhip_yaw_id = 0  # Right hip yaw joint index (adjust if needed)
Lhip_yaw_id = 6  # Left hip yaw joint index (adjust if needed)

# Fix the torso in place by constraining hip yaw joints
p.createConstraint(
    parentBodyUniqueId=robot_id, 
    parentLinkIndex=Rhip_yaw_id, 
    childBodyUniqueId=robot_id, 
    childLinkIndex=Lhip_yaw_id,
    jointType=p.JOINT_FIXED,
    jointAxis=[0, 0, 0],
    parentFramePosition=[0, 0, 1],
    childFramePosition=[0, 0, 1]
)

# Fix all joints except the pendulum
for joint_id in range(num_joints):
    if joint_id not in [roll_joint, pitch_joint]:
        p.setJointMotorControl2(robot_id, joint_id, p.POSITION_CONTROL, targetPosition=0, force=500)

# Create real-time sliders for adjusting roll and pitch angles
roll_slider = p.addUserDebugParameter("Roll Angle", -0.5, 0.5, 0.0)
pitch_slider = p.addUserDebugParameter("Pitch Angle", -0.5, 0.5, 0.0)

# Function to calculate and visualize COM
def visualize_com():
    com_pos, _ = p.getBasePositionAndOrientation(robot_id)
    
    # Remove old indicators
    p.removeAllUserDebugItems()
    
    # Draw vertical line from COM to the ground
    p.addUserDebugLine([com_pos[0], com_pos[1], com_pos[2]], [com_pos[0], com_pos[1], 0], [1, 0, 0], 2)
    
    # Draw a circle at COM location
    p.addUserDebugText("COM", [com_pos[0], com_pos[1], com_pos[2]], textColorRGB=[1, 0, 0], textSize=1.2)

# Run the simulation
while True:
    roll_angle = p.readUserDebugParameter(roll_slider)
    pitch_angle = p.readUserDebugParameter(pitch_slider)
    
    p.setJointMotorControl2(robot_id, roll_joint, p.POSITION_CONTROL, targetPosition=roll_angle)
    p.setJointMotorControl2(robot_id, pitch_joint, p.POSITION_CONTROL, targetPosition=pitch_angle)
    
    visualize_com()
    
    p.stepSimulation()
    time.sleep(0.01)

# Disconnect from PyBullet
p.disconnect()
