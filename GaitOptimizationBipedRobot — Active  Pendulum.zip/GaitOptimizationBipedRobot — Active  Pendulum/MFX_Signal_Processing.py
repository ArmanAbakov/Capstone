#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun  4 14:52:15 2021

@author: folgheraitermichele

Set of Signal Processing Modules that can be used in real time or inside simulation loops. 
They correspond to blocks in Simulink.

Implemented anti windup in the PID block: DONE
"""
Plot=False

import numpy as np

import matplotlib.pyplot as plt


class MovingAverage:
    ### MFX_Python3_Software ###
    ### Moving average Filter with window of dimension equal to the FilterOrder
    def __init__(self,FilterOrder):
        self.Stack=np.zeros(FilterOrder)
        self.FilterOrder=FilterOrder
        self.WarmUpIndex=FilterOrder
        
    def Filter(self,Sample):    
            
        for  indx_Filter in range (self.FilterOrder-1):
            self.Stack[indx_Filter]=self.Stack[indx_Filter+1]
                 
        self.Stack[self.FilterOrder-1]=Sample   
        
        if self.WarmUpIndex==0: # Warm-Up procedure completed 
            Sum=0
            for  indx_Filter in range (self.FilterOrder):
                Sum=Sum+self.Stack[indx_Filter]
 
            FilteredSignal=Sum/self.FilterOrder
            return(FilteredSignal)
        else:  # if there are not enough samples for the full average use only the samples available
            Sum=0
            for  indx_Filter in range (self.FilterOrder-(self.WarmUpIndex-1)):
                Sum=Sum+self.Stack[self.FilterOrder-indx_Filter-1]
            self.WarmUpIndex=self.WarmUpIndex-1
            FilteredSignal=Sum/(self.FilterOrder-(self.WarmUpIndex-1))
            if self.WarmUpIndex==0:
                print("Filter Warmed Up!")
            return(FilteredSignal)
  
class LowPassFilter:
    def __init__(self,TimeConstant=0.01,SampleTime=0.01):
        ### MFX_Python3_Software ###
        ### Low Pass Filter, implemented from wikipedia.
        self.alpha=SampleTime/(TimeConstant+SampleTime)
        self.FilteredSignal_tp=0
        self.TimeConstant=TimeConstant
    
        
    def Filter(self,Sample):    
        
        FilteredSignal=(self.alpha)*Sample+(1-self.alpha)*self.FilteredSignal_tp
        self.FilteredSignal_tp=FilteredSignal
        return(FilteredSignal)
    
    # The filter signal correspond for 80% from the past and 20% for the current signal    
    def Filter8020(self,Sample):
        FilteredSignal=0.8*self.FilteredSignal_tp+0.2*Sample
        self.FilteredSignal_tp=FilteredSignal
        return(FilteredSignal)
    
    # Return the CutOff frequency of the filter    
    def CutOffFrequenzy(self):
        return(1/(2*np.pi*self.TimeConstant))    
    
    
    

        

class PID:
    def __init__(self,kp,ki,kd,SampleTime,windup_limit=1000):
        ### MFX_Python3_Software ###
        ### PID, to implement  anti-windup: Implemented
        self.kp=kp
        self.ki=ki
        self.kd=kd
        self.SampleTime=SampleTime
        self.windup_limit=windup_limit
        self.past_err=0
        self.integral_err=0
        self.CONTROL_ACTION=[]
        self.NumberOfSample=0
        self.ERROR=[]
        
   
        
    def Controller(self,err):    
        
        self.NumberOfSample=self.NumberOfSample+1
        self.integral_err=self.integral_err+err*self.SampleTime  #Integral of the error
        self.derivative_err=(err-self.past_err)/self.SampleTime  # Derivative of the error
        self.PControlAction=self.kp*err
        self.IControlAction=self.ki*self.integral_err
        self.IControlAction=min(max(self.IControlAction, -self.windup_limit), self.windup_limit)
        if (self.NumberOfSample==1):
            self.DControlAction=0 # To avoid very big derivative at the first sample 
        else:    
            self.DControlAction=self.kd*self.derivative_err
        self.CONTROL_ACTION.append([self.PControlAction,self.IControlAction,self.DControlAction])
        self.ERROR.append(err)
        self.past_err=err
        ControlAction=self.PControlAction+self.IControlAction+self.DControlAction # CONTROL ACTION
        
        
        return(ControlAction)      
    
    # Returns all the separate control actions samples as a list
    def CONTROL_ACTION(self):  
        return(self.CONTROL_ACTION)  
    #Returns the Root Mean Square Error on all the sample processed so far
    def RMS(self):
        sum=0
        for i in range (len(self.ERROR)):
            sum=sum+(self.ERROR[i])**2
        RMS=np.sqrt(sum/self.NumberOfSample)
        return(RMS)
    #Returns the Mean Square Error on all the sample processed so far
    def MSE(self):
        sum=0
        for i in range (len(self.ERROR)):
            sum=sum+(self.ERROR[i])**2
        MSE=sum/self.NumberOfSample
        return(MSE)
 
   
class Derivative:
        def __init__(self,SampleTime):
            self.past_sample=0
            self.SampleTime=SampleTime
            self.init=0
        def Derive(self,sample):
            if self.init==0:
                derivative=0
                self.past_sample=sample
                self.init=1
            else:
                derivative=(sample-self.past_sample)/self.SampleTime
                self.past_sample=sample
            return (derivative)

       
class Integral:
        def __init__(self,SampleTime,Init):
            self.past_sample=0
            self.past_Integral=Init
            self.SampleTime=SampleTime
        def Integrate(self,sample):
            
            Integral=self.past_Integral+((sample+self.past_sample)/2)*self.SampleTime
            
            #Trapezoidal method:
            #Integral=self.past_Integral+self.past_sample*(self.SampleTime/2)
            # Euler Method
            #Integral=self.past_Integral+self.SampleTime*sample
            

            
            self.past_sample=sample
            self.past_Integral=Integral
            return (Integral)

# To verify             
class LeakyIntegral:
        def __init__(self,SampleTime=1,Init=0,Threshold=0.1,LeakyConst=1):
            self.past_sample=0
            self.past_Integral=Init
            self.SampleTime=SampleTime
            self.LeakyConst=LeakyConst
            self.State=0
            self.Threshold=Threshold
            self.ActivateInt=0
        def Integrate(self,sample):
            if ((np.abs(sample)<self.Threshold)and(self.State==0)):
                LeakyGain=0 # if no inpulse is encontered yet do not activate the Leakage and the Integrator
            else:
                self.State=1
                self.ActivateInt=1 # Start to integrate the signal
                LeakyGain=self.LeakyConst
            Integral=self.ActivateInt*(self.past_Integral+((sample+self.past_sample)/2)*self.SampleTime)-LeakyGain*self.past_Integral
            self.past_sample=sample
            self.past_Integral=Integral
            return (Integral)        

# Class to perform Normalization and Denormalization in the ranges [-1, +1]  and [0, +1]. It accept data in the form
# np.array, where you have multiple features data (where each column represents one feature and the rows the samples) 
# and gives back results as np.array. It normalize only one set of data, you can not renormalize the
# same data, however you can denormalize different set of data with the same  NormalizeData object.

# If 

class NormalizeData:
    def __init__(self,):   
        self.DataNormalized_Min1_Plus1=[]
        self.DataDeNormalized_Min1_Plus1=[]
        self.DataNormalized_Zero_Plus1=[]
        self.DataDeNormalized_Zero_Plus1=[]
        self.DimData=[]
        self.MinData=[]
        self.MaxData=[]
        self.DataAreNormalized_Min1_Plus1=0
        self.DataAreNormalized_Zero_Plus1=0
        
        
    
    def Normalize_Min1_Plus1(self,Data): 
        self.DimData=np.shape(Data)
        # I have more than one sample calcuate the min and max for each feature
        if (self.DimData[0]>1):  
            self.MinData=np.amin(Data,axis=0)
            self.MaxData=np.amax(Data,axis=0)
        self.DataNormalized_Min1_Plus1=np.zeros([Data.shape[0],Data.shape[1]])
        # Normilization in the range [-1,+1]
        if(not(self.DataAreNormalized_Min1_Plus1)or(self.DimData[0]==1)):
            for i in range (self.DimData[0]):
                for j in range (self.DimData[1]):
                    self.DataNormalized_Min1_Plus1[i,j]=((2*(Data[i,j]-self.MinData[j])/(self.MaxData[j]-self.MinData[j]))-1)
                    self.DataAreNormalized_Min1_Plus1=1
        return(self.DataNormalized_Min1_Plus1)  
    
    def DeNormalize_Min1_Plus1(self,Data): 
        self.DataDeNormalized_Min1_Plus1=np.zeros([Data.shape[0],Data.shape[1]])
        # Recalculate the data dimension, needed in case I want to denormalize a different number of samples 
        DimData=np.shape(Data)
        for i in range (DimData[0]):
            for j in range (DimData[1]):
                self.DataDeNormalized_Min1_Plus1[i,j]=((((Data[i,j]+1)*(self.MaxData[j]-self.MinData[j]))/2)+self.MinData[j])
        return(self.DataDeNormalized_Min1_Plus1) 
         
            
    def Normalize_Zero_Plus1(self,Data): 
        self.DimData=np.shape(Data)
        if (self.DimData[0]>1):  
            self.MinData=np.amin(Data,axis=0)
            self.MaxData=np.amax(Data,axis=0)
        self.DataNormalized_Zero_Plus1=np.zeros([Data.shape[0],Data.shape[1]])
        # Normilization in the range [0,+1]
        if(not(self.DataAreNormalized_Zero_Plus1)or(self.DimData[0]==1)):
            for i in range (self.DimData[0]):
                for j in range (self.DimData[1]):
                    self.DataNormalized_Zero_Plus1[i,j]=(((Data[i,j]-self.MinData[j])/(self.MaxData[j]-self.MinData[j])))  
                    self.DataAreNormalized_Zero_Plus1=1
        return(self.DataNormalized_Zero_Plus1)    
    
    def DeNormalize_Zero_Plus1(self,Data): 
        self.DataDeNormalized_Zero_Plus1=np.zeros([Data.shape[0],Data.shape[1]])
        # Recalculate the data dimension, needed in case I want to denormalize a different number of samples 
        DimData=np.shape(Data)
        for i in range (DimData[0]):
            for j in range (DimData[1]):
                self.DataDeNormalized_Zero_Plus1[i,j]=((((Data[i,j])*(self.MaxData[j]-self.MinData[j])))+self.MinData[j])
        return(self.DataDeNormalized_Zero_Plus1)  
    
    
# Class that allows to calculate the FFT of a signal given as a vector of samples and plot it in a nice way
  
class FFTAnalyzer:
    def __init__(self, signal, sampling_time,num_components,title="FFT of Signal"):
        self.signal = signal
        self.sampling_time = sampling_time
        self.num_components = num_components
        self.title=title
    
    def FFT(self):
        """Computes the FFT of the signal and returns the specified number of principal components and corresponding frequencies, sorted by decreasing amplitude."""
        n = len(self.signal)
        yf = np.fft.fft(self.signal)
        xf = np.linspace(0.0, 1.0/(2.0*self.sampling_time), n//2)
        amp = 2.0/n * np.abs(yf[0:n//2])
        idx = np.argsort(amp)[::-1][:self.num_components]
        freqs = xf[idx]
        pcs = np.abs(yf[0:n//2][idx])
        return pcs, freqs
    
    def plot_fft(self):
        """Computes the FFT of the signal and plots the specified number of principal components and corresponding frequencies."""
        pcs, freqs = self.FFT()
        plt.figure(figsize=(8, 6))
        width = np.diff(freqs).mean() * 0.1*np.log(self.num_components)
        plt.bar(freqs, pcs, width)
        plt.grid("on")
        plt.xlabel('Frequency (Hz)')
        plt.ylabel('Amplitude')
        plt.title(self.title)
        plt.show()
              


if Plot:        
    
    # Verification Integral, you should be able to obtain a (1/w)*sin(wt)+0 function from the integral of cos(wt) and -w*cos(wt)+w
    # from the integral of sin(wt)
    SamplingTime=0.01    
    Integrator=Integral(SamplingTime,Init=0)
    y=[]
    iy=[]
    time=[]
        
    f=1
    
    for i in range(200):
        t=i*SamplingTime
        w=2*np.pi*f
        y.append(np.sin(w*t))
        iy.append(Integrator.Integrate(y[i]))
        time.append(i*SamplingTime)
        
        
    fig10 = plt.figure()
    ax0 = fig10.gca()
    ax0.plot(time,y)
    ax0.plot(time,iy)
    ax0.set(xlabel='Time [s]', ylabel='Signals', title='')
    ax0.grid(b=True, which='major', color=[0.75, 0.75, 0.75], linestyle='-.')      
        
    # Verification Derivative
    
    SamplingTime=0.01    
    Derivator=Derivative(SamplingTime)
    y=[]
    dy=[]
    time=[]
        
    
    for i in range(200):
        t=i*SamplingTime
        w=2*np.pi*f
        y.append(np.sin(w*t))
        dy.append(Derivator.Derive(y[i]))
        time.append(i*SamplingTime)
        
        
    fig10 = plt.figure()
    ax0 = fig10.gca()
    ax0.plot(time,y)
    ax0.plot(time,dy)
    ax0.set(xlabel='Time [s]', ylabel='Signals', title='')
    ax0.grid(b=True, which='major', color=[0.75, 0.75, 0.75], linestyle='-.')  
    
    
    #------------ PID Example -----------------------
    SamplingTime=0.01 
    PID1=PID(10,1,1,SamplingTime)
    ReferenceValue=10
    ActualValue=1 # This shold be the sensor acquisition, e.g., the joint position
    time=[]
    ControlTime=10 # How many senconds the control loop will be operative
    NumberSamples=int(ControlTime/SamplingTime)
    
    # Control Loop
    for i in range(NumberSamples):
        time.append(i*SamplingTime)
        error=ReferenceValue-ActualValue
        controlAction=PID1.Controller(error)
    
    ControlAction=PID1.CONTROL_ACTION
    
    
    #-------------Data Normalization-Denormalization----------------
    
    data=np.array([[5,4],[4,2],[4,7],[3,8]])
    Normalizer=NormalizeData()

    
    dataN=Normalizer.Normalize_Min1_Plus1(data)
    
    dataD=Normalizer.DeNormalize_Min1_Plus1(dataN)
      
    dataN2=Normalizer.Normalize_Zero_Plus1(data)
    
    dataD2=Normalizer.DeNormalize_Zero_Plus1(dataN2)