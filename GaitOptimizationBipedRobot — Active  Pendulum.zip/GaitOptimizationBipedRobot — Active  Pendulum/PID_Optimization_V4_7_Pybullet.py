"""!/usr/bin/env python3
-*- coding: utf-8 -*-

ATTENTION: in Mac M2 press the button "g" to hide utility, this way, rendering runs fast as Ubuntu. 
Even faster if you eliminate shadow, press button "s".

LONG TERM TO DO: 
1) Implement Time Scaling: It would be good to divide the Cartesian path in different segments and execute
them at different sampling time (different speed, for example I guess that the step forward part should be execute 
faster than the later motion part.)
2) Implement ZMP trajectory optimization, it require to calculate the ZMP using a simplified dynamic model or using
the force sensors.  When a robot moves, its inertia creates additional forces and moments. The ZMP position shifts 
in response to these dynamic effects. Therefore, the rate of change of the ZMP can reflect how quickly and in what 
manner the robot's inertia is affecting its balance.The ZMP is the point on the ground where the resultant moment due
to gravity and inertia, about the horizontal axes (x,y), is zero.    
Created on Thu Aug 31 18:39:46 2023

   I changed the offset along the y-axis from l2/2 to l2 

@author: folghera
This program applis a RANDOM GRID SEARCH to find the optimal hyperparameters to scale the Cartesian 
trajectory on the base of the Gait performamces (distance covered and energy consumed).

STATUS:  V3 Working

TO DO:
    - Remember the tested combinations: DONE
    - Plot the Optimal Point in RED
    - 

    
    
    OptimalPID= {'P': 0.97, 'I': 0.085, 'D': 0.29}
    OptimalPID= {'P': 0.29, 'I': 0.029, 'D': 0.7}

    - Better Camera View
    
   
 
"""

from OneStep_V4_7_PyBullet_3 import *
import itertools
import numpy as np
import sys 
from PlotTrajectories_V4_7 import Scale,ChangeDistance,PlotFeetTrajectory                          #pip install dill --user
filename = './Experiments/Gait_33s_Exp2_NU_4_7.pkl' #Paper Data
#filename = './Experiments/Gait_33s_Exp2_400/Gait_33s_Exp2_400.pkl'
#dill.dump_session(filename)

# # # and to load the session again:
#dill.load_session(filename)

import random
import time
import matplotlib.pyplot as plt
plt.style.use('MFX_Plot.mplstyle')
import MFX_Signal_Processing as MFX_SP  
import copy

import pybullet as p    
# With  visualization
#physicsClient = p.connect(p.GUI)
# Without Visualization
physicsClient = p.connect(p.DIRECT) 

import os

# Add /opt/local/bin to the PATH for MAC M2
os.environ['PATH'] = "/opt/local/bin:" + os.environ['PATH']


# Print iterations progress
def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total: 
        print()


# Define your hyper-parameter search space
# Observing that the distance increases with smaller scale_y factors I introduced also values small than one 

# # # Reduced Hyperparameters Space


param_space = {
    'P': list(np.arange(0, 2, 0.01)),
    'I': list(np.arange(0, 0.2, 0.001)),
    'D': list(np.arange(0, 1, 0.01))
}



NumberOfTrials=200

GridDimension=1
for key, value in param_space.items():
    print(value)
    GridDimension=GridDimension*len(value)
    
RandomGridAdvantage=GridDimension/NumberOfTrials
print("Number of possible configurations=",GridDimension)
print("Doing a Random Grid Search Will Be",RandomGridAdvantage,"time faster than a normal Grid Search" )

# Generate all possible combinations of hyperparameters
param_combinations = list(itertools.product(*param_space.values()))
random.shuffle(param_combinations)  # Randomize the order

selected_combinations = param_combinations[:NumberOfTrials]  # Select the first `NumberOfTrials` combinations




Performance=[]
NumberFalls=0

# The PID is optimized on the base of a good gait
OptConfigDict={'scale_x': 4, 'scale_y': 0.7, 'scale_z': 1.4, 'DistanceOffSet': -0.02, 'KneeBendDist': -0.07}
for i, random_config in enumerate(selected_combinations):
    # Reload initial trajectories
    from FootTrajectories import * 
    printProgressBar(i, NumberOfTrials, prefix = 'Progress:', suffix = 'Complete', length = 40)
    
    start_time = time.time()
    # Implement a Random Gris Search
    #random_config = {param: random.choice(values) for param, values in param_space.items()}
    
    # Map the selected combination back to a dictionary
    random_config_dict = dict(zip(param_space.keys(), random_config))
    
    print("\n Running Configuration=", random_config_dict)
    
    # Scale the Cartesian Trajectory to be Optimal
    
    rightFootPathData, leftFootPathData = Scale(rightFootPathData, leftFootPathData,
                                                [OptConfigDict['scale_y'], OptConfigDict['scale_x'], OptConfigDict['scale_z']])
    
    rightFootPathData, leftFootPathData = ChangeDistance(rightFootPathData, leftFootPathData, OptConfigDict['DistanceOffSet'])
    # Execute the trajectory
    GaitSuccess, CoveredDistance, EnergyConsumed, AverageABSMechanicalPower, StdMechanicalPower, FramesSequence, TorqueSmoothnessN, TotJointsMeanError,JointTrackingErrors = Execute_Gate(
        rightFootPathData, leftFootPathData, NumberOfFullStepSequence=6, KneeBendDist=OptConfigDict['KneeBendDist'],
        PLOT=False, Home=False, Lifted=False, AcquireFrames=False, SamplingFrameFrequency=100,
        physicsClient=physicsClient,PID=[random_config_dict['P'],random_config_dict['I'],random_config_dict['D']]
    )
    
    end_time = time.time()
    
    if GaitSuccess:
        Performance.append([random_config_dict, TotJointsMeanError,EnergyConsumed])
        if i == 0:
            print("-----------------------------------------------------------")
            print("This simulation will require about", ((end_time - start_time) * NumberOfTrials) / 60, " minutes")
            print("-----------------------------------------------------------")
            time.sleep(3)
    else:
        NumberFalls += 1       

# Normalizing and evaluating the best configuration
p.disconnect()

# To run the optimal configuration

from FootTrajectories import *


physicsClient = p.connect(p.GUI)


Performance = np.array(Performance).reshape((len(Performance), 3))

PositionErrorEnergy = Performance[:, 1:3]
Normalizer = MFX_SP.NormalizeData()
PositionErrorEnergN = Normalizer.Normalize_Zero_Plus1(PositionErrorEnergy)
PerformanceN = np.copy(Performance)
PerformanceN[:, 1:3] = PositionErrorEnergN

# Select the best configuration
OptConfigPID = Performance[np.argmin(0.6*PerformanceN[:, 1]+0.4*PerformanceN[:, 2])] 
# Map the best configuration back to a dictionary
OptConfigPIDDict = OptConfigPID[0]


print("--> OPTIMAL CONFIGURATION=", OptConfigPIDDict)

rightFootPathData, leftFootPathData = Scale(rightFootPathData, leftFootPathData,
                                                [OptConfigDict['scale_y'], OptConfigDict['scale_x'], OptConfigDict['scale_z']])
    
rightFootPathData, leftFootPathData = ChangeDistance(rightFootPathData, leftFootPathData, OptConfigDict['DistanceOffSet'])

# Execute the trajectory with the optimal configuration
GaitSuccess, CoveredDistance, EnergyConsumed, AverageABSMechanicalPower, StdMechanicalPower, FramesSequence, TorqueSmoothness, TotJointsMeanError, JointTrackingErrors = Execute_Gate(
    rightFootPathData, leftFootPathData, NumberOfFullStepSequence=6, KneeBendDist=OptConfigDict['KneeBendDist'],
    PLOT=True, Home=False, Lifted=False, AcquireFrames=True, SamplingFrameFrequency=150,
    physicsClient=physicsClient,PID=[OptConfigPIDDict['P'],OptConfigPIDDict['I'],OptConfigPIDDict['D']]
)

PlotFeetTrajectory(rightFootPathData, leftFootPathData, l2=0.180)

p.disconnect()

