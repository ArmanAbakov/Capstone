#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 17:02:38 2022

@author: folghera
"""
from scipy.spatial.transform import Rotation as R
import numpy as np

theta=np.deg2rad(-45)

rx = R.from_matrix([[1 , 0, 0],
                   [0, np.cos(theta), -np.sin(theta)],
                   [0 , np.sin(theta), np.cos(theta)]])

ry = R.from_matrix([[np.cos(theta) , 0, np.sin(theta)],
                   [0, 1, 0],
                   [-np.sin(theta) , 0, np.cos(theta)]])

q=ry.as_quat()

xi=+2.3433e-01;
yi=-1.1762e-02;
zi=0.01;

LinearTrajectory=[]

for i in range (104):
    LinearTrajectory.append(xi)
    LinearTrajectory.append(yi)
    z=zi+i*0.002
    LinearTrajectory.append(z)
    LinearTrajectory.append(q[0])
    LinearTrajectory.append(q[1])
    LinearTrajectory.append(q[2])
    LinearTrajectory.append(q[3])
    
    
for i in range (105,209):
    LinearTrajectory.append(xi)
    LinearTrajectory.append(yi)
    LinearTrajectory.append(z-(i-105)*0.002)
    LinearTrajectory.append(q[0])
    LinearTrajectory.append(q[1])
    LinearTrajectory.append(q[2])
    LinearTrajectory.append(q[3])
    
    
