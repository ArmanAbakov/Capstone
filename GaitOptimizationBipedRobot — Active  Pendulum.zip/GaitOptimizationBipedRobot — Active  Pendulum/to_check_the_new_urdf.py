
    
import pybullet as p
import pybullet_data
import time


# Initialize the physics server
if p.isConnected():
    p.disconnect()
p.connect(p.GUI)

# Set up URDF search path and environment
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -9.81)

# Try to load the built-in plane.urdf from PyBullet's default path
p.loadURDF("plane.urdf")

# Load your URDF robot model (replace 'your_robot.urdf' with the path to your URDF file)
robot_id = p.loadURDF("nu_biped_final.urdf", basePosition=[0, 0, 0.5])


# Get the number of joints (which includes links)
num_joints = p.getNumJoints(robot_id)
print(f"Number of joints: {num_joints}")

# Print link names and IDs
for i in range(num_joints):
    info = p.getJointInfo(robot_id, i)
    print(f"Joint Index: {info[0]}, Name: {info[1].decode('utf-8')}")
    
# Set the camera closer to the robot
camera_distance = 2.5  # Distance from the robot
camera_yaw = 55      # Angle around the robot
camera_pitch = -40   # Angle above the robot
camera_target = [0, 0, 0.5]  # Focus point (robot's torso)

p.resetDebugVisualizerCamera(
    cameraDistance=camera_distance,
    cameraYaw=camera_yaw,
    cameraPitch=camera_pitch,
    cameraTargetPosition=camera_target
)


# Start the simulation loop
while True:
    p.stepSimulation()
    time.sleep(1. / 240.)  # Set the simulation rate (240 Hz is typical)

