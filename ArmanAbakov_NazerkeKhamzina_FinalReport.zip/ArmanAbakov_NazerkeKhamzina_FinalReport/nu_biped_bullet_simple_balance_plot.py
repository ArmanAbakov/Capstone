import pybullet as p
import pybullet_data
import time
import numpy as np
import matplotlib.pyplot as plt

# Initialize the physics server
if p.isConnected():
    p.disconnect()
p.connect(p.GUI)

# Set up environment
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -9.81)
p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)

# Load environment and robot
plane_id = p.loadURDF("plane.urdf")
robot_id = p.loadURDF("nu_biped_sim_bullet.urdf", basePosition=[0, 0, 0])

num_joints = p.getNumJoints(robot_id)

# Create joint and link maps
joint_map = {p.getJointInfo(robot_id, i)[1].decode('utf-8'): i for i in range(num_joints)}
link_map = {("base_link" if i == -1 else p.getJointInfo(robot_id, i)[12].decode('utf-8')): i for i in range(-1, num_joints)}

# Set the camera position
p.resetDebugVisualizerCamera(cameraDistance=0.4, cameraYaw=0, cameraPitch=-20, cameraTargetPosition=[0, 0, 0.1])

# Function to calculate the full COM position
def calculate_com(robot_id):
    total_mass = 0.0
    weighted_position = np.array([0.0, 0.0, 0.0])
    
    base_state = p.getBasePositionAndOrientation(robot_id)
    base_mass = p.getDynamicsInfo(robot_id, -1)[0]
    base_position = np.array(base_state[0])
    
    total_mass += base_mass
    weighted_position += base_position * base_mass
    
    for link_id in range(num_joints):
        link_state = p.getLinkState(robot_id, link_id)
        mass = p.getDynamicsInfo(robot_id, link_id)[0]
        position = np.array(link_state[0])
        
        total_mass += mass
        weighted_position += position * mass
    
    return weighted_position / total_mass

# Simulation parameters
time_step = 1. / 240.
chill_time = 2.0

# Lists to store positions
time_list = []
com_x_list, com_y_list, com_z_list = [], [], []
foot_x_list, foot_y_list, foot_z_list = [], [], []

start_time = time.time()

# Chill period for observation
while time.time() - start_time < chill_time:
    p.stepSimulation()
    time.sleep(time_step)

explicitly_controlled_joints = {
    joint_map['R_Hip_Pitch'], 
    joint_map['R_Knee'], 
    joint_map['R_Ankle_Pitch'], 
    joint_map['Pendulum_Pitch'], 
    joint_map['Pendulum_Roll']
}

# Simulation loop
for step in range(10000):  # Adjust the number of steps as needed
    current_time = time.time() - start_time

    # Step simulation
    p.stepSimulation()
    time.sleep(time_step)
    
    # Dynamic foot position
    standing_foot_index = link_map['L_Foot_Respondable']
    standing_foot_position = p.getLinkState(robot_id, standing_foot_index)[0]
    standing_foot_projection = np.array([standing_foot_position[0], standing_foot_position[1], 0.0])
    
    # Calculate COM projection
    com = calculate_com(robot_id)
    com_projection = np.array([com[0], com[1], 0.0])
    
    # Record positions
    time_list.append(current_time)
    com_x_list.append(com[0])
    com_y_list.append(com[1])
    com_z_list.append(com[2])
    foot_x_list.append(standing_foot_position[0])
    foot_y_list.append(standing_foot_position[1])
    foot_z_list.append(standing_foot_position[2])
    
    # Gradual leg lift keeping the foot parallel to the floor
    timestamp = 3000
    hip_target = max(-0.5, (-step+timestamp) * 0.001)
    knee_target = min(1.0, (step-timestamp) * 0.002)
    ankle_target = max(-0.5, (-step+timestamp) * 0.001)
    roll_target = max(-0.708, (-step)*0.00025)
    pitch_target = min(0.1, (step)*0.00025)
    
    if step > timestamp:
        p.setJointMotorControl2(robot_id, joint_map['R_Hip_Pitch'], p.POSITION_CONTROL, targetPosition=hip_target)
        p.setJointMotorControl2(robot_id, joint_map['R_Knee'], p.POSITION_CONTROL, targetPosition=knee_target)
        p.setJointMotorControl2(robot_id, joint_map['R_Ankle_Pitch'], p.POSITION_CONTROL, targetPosition=ankle_target)
    
    p.setJointMotorControl2(robot_id, joint_map['Pendulum_Pitch'], p.POSITION_CONTROL, targetPosition=0)
    p.setJointMotorControl2(robot_id, joint_map['Pendulum_Roll'], p.POSITION_CONTROL, targetPosition=roll_target)
    
    # Iterate over all joints
    for joint_index in range(num_joints):
        if joint_index not in explicitly_controlled_joints:
            p.setJointMotorControl2(robot_id, joint_index, p.POSITION_CONTROL, targetPosition=0)
    
    # Visual debug lines
    p.addUserDebugLine(lineFromXYZ=com, lineToXYZ=com_projection, lineColorRGB=[1, 0, 1], lifeTime=0.01)  # Purple
    p.addUserDebugLine(lineFromXYZ=com_projection, lineToXYZ=standing_foot_projection, lineColorRGB=[1, 0, 0], lifeTime=0.01)  # Red

# Plot the data
plt.figure(figsize=(10, 8))

# X position plot
plt.subplot(2, 1, 1)
plt.plot(time_list, com_x_list, label="COM X Position", color='b')
plt.plot(time_list, foot_x_list, label="Standing Foot X Position", color='r')
plt.xlabel("Time (s)")
plt.ylabel("X Position (m)")
plt.legend()
plt.title("X Position vs Time")
'''
# Y position plot
plt.subplot(3, 1, 2)
plt.plot(time_list, com_y_list, label="COM Y Position", color='b')
plt.plot(time_list, foot_y_list, label="Standing Foot Y Position", color='r')
plt.xlabel("Time (s)")
plt.ylabel("Y Position (m)")
plt.legend()
plt.title("Y Position vs Time")
'''
# Z position plot
plt.subplot(2, 1, 2)
plt.plot(time_list, com_z_list, label="COM Z Position", color='b')
plt.xlabel("Time (s)")
plt.ylabel("Z Position (m)")
plt.legend()
plt.title("Z Position vs Time")

# Adjust layout and show plot
plt.tight_layout()
plt.show()
