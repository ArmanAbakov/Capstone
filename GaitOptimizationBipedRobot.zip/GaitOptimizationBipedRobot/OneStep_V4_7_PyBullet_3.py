#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 24 16:10:14 2024

@author: folghera

TO SOLVE:
    - 

TO DO:
    - Implement Plot Real vs Target Pos: DONE
    - Introducce the initial knee bending as an aditional hyperparameter: IMPLEMENTED TO TEST
    - Add the optimal confif point in red in the plots.
"""

import time
import pybullet as p
import pybullet_data
from Biped_IK import *

import numpy as np
import matplotlib.pyplot as plt
plt.style.use('MFX_Plot.mplstyle')
import MFX_Signal_Processing as MFX_SP
import math
import dill   # To save and load the workspace variable in a file

from PIL import Image, ImageOps


def PrintMainFrame(p,robotId):
    
    # Define the length of the axes
    axis_length = 0.3
    
    # Get the position and orientation of the base link
    basePosition, baseOrientation = p.getBasePositionAndOrientation(robotId)
    
    # Get the rotation matrix from the base orientation quaternion
    rotationMatrix = p.getMatrixFromQuaternion(baseOrientation)
    
    # Extract the rotation matrix components
    rotX = [rotationMatrix[0], rotationMatrix[1], rotationMatrix[2]]
    rotY = [rotationMatrix[3], rotationMatrix[4], rotationMatrix[5]]
    rotZ = [rotationMatrix[6], rotationMatrix[7], rotationMatrix[8]]
    
    # Define the end points of the axes in the world frame
    x_end = [basePosition[0] + axis_length * rotX[0], 
             basePosition[1] + axis_length * rotX[1], 
             basePosition[2] + axis_length * rotX[2]]
    
    y_end = [basePosition[0] + axis_length * rotY[0], 
             basePosition[1] + axis_length * rotY[1], 
             basePosition[2] + axis_length * rotY[2]]
    
    z_end = [basePosition[0] + axis_length * rotZ[0], 
             basePosition[1] + axis_length * rotZ[1], 
             basePosition[2] + axis_length * rotZ[2]]
    
    # Draw the axes
    p.addUserDebugLine(basePosition, x_end, [1, 0, 0], 2)  # X-axis in red
    p.addUserDebugLine(basePosition, y_end, [0, 1, 0], 2)  # Y-axis in green
    p.addUserDebugLine(basePosition, z_end, [0, 0, 1], 2)  # Z-axis in blue

def VectorSignalsDerivative(VectorSignals, SampleTime):
    dim = VectorSignals.shape
    DerSign = [[0] * dim[2] for i in range(dim[1])]
    FilterDerSign = [[0] * dim[2] for i in range(dim[1])]
    DerivativeVectorSignals = np.zeros([dim[0], dim[1], dim[2]])
    for sig1 in range(dim[1]):
        for sig2 in range(dim[2]):
            DerSign[sig1][sig2] = MFX_SP.Derivative(SampleTime)
            FilterDerSign[sig1][sig2] = MFX_SP.MovingAverage(FilterOrder=5)
            for i in range(dim[0]):
                if i == 0:
                    DerivativeVectorSignals[i, sig1, sig2] = 0
                else:
                    DerivativeVectorSignals[i, sig1, sig2] = DerSign[sig1][sig2].Derive(VectorSignals[i, sig1, sig2])
                    DerivativeVectorSignals[i, sig1, sig2] = FilterDerSign[sig1][sig2].Filter(DerivativeVectorSignals[i, sig1, sig2])
    return DerivativeVectorSignals

def printProgressBar(iteration, total, prefix='', suffix='', decimals=1, length=100, fill='█', printEnd="\r"):
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total: 
        print()


def ReadSample(i, rightFootPathData, leftFootPathData):
    coord = rightFootPathData[7 * i:7 * i + 7]
    coord2 = leftFootPathData[7 * i:7 * i + 7]

    Q = coord[3:7]
    px = -coord[1]
    py = coord[0]
    pz = coord[2]

    Q2 = coord2[3:7]
    px2 = -coord2[1]
    py2 = coord2[0]
    pz2 = coord2[2]

    ux, uy, uz, vx, vy, vz, wx, wy, wz = quaternion_rotation_matrix(Q)
    ux2, uy2, uz2, vx2, vy2, vz2, wx2, wy2, wz2 = quaternion_rotation_matrix(Q2)

    RightFootPose = [ux, uy, uz, vx, vy, vz, wx, wy, wz, px, py, pz]
    LeftFootPose = [ux2, uy2, uz2, vx2, vy2, vz2, wx2, wy2, wz2, px2, py2, pz2]
    return RightFootPose, LeftFootPose

def Change_Joints_PID(robot, joint_indices, P, D):
    for joint_index in joint_indices:
        p.setJointMotorControl2(robot, joint_index, p.VELOCITY_CONTROL, force=0)
        p.setJointMotorControl2(robot, joint_index, p.POSITION_CONTROL, positionGain=P, velocityGain=D, force=40)
        
        

def Calculate_mechanical_power_energy(robot_id, initial_pos, sim_joint_positions,sim_joint_velocities, sim_joint_torques, sample_time, full_step_sequence_iterations, left_foot_path_data):
    energy_consumed = 0
    average_abs_mechanical_power = 0
    std_mechanical_power = 0
    

    # Calculate and update covered distance
    current_position = p.getBasePositionAndOrientation(robot_id)[0]
    covered_distance = np.linalg.norm(np.array(current_position) - np.array(initial_pos))
    
    # Convert the lists to arrays
 
    sim_joint_positions = np.array(sim_joint_positions)
    sim_joint_velocities = np.array(sim_joint_velocities)
    sim_joint_torques = np.array(sim_joint_torques)
    
    
    # Calculate the joint velocities
    #sim_joint_velocities = vector_signals_derivative(sim_joint_positions, sample_time)
    
    # Instantaneous Total (all joints together) Mechanical Power [W]
    total_mechanical_power = []
    integral_power = Integral(sample_time, 0)
    
    TotalSamples=full_step_sequence_iterations * (int(len(left_foot_path_data) / 7))
    print("TotalSamples=",TotalSamples)
    for i in range(TotalSamples):
        total_mechanical_power.append(
            np.sum(np.multiply(np.abs(sim_joint_velocities[i, :]), np.abs(sim_joint_torques[i, :]))))
        
        energy_consumed = integral_power.integrate(total_mechanical_power[i])
    
    total_mechanical_power = np.array(total_mechanical_power)
    average_abs_mechanical_power = np.mean(np.abs(total_mechanical_power))
    std_mechanical_power = np.std(np.abs(total_mechanical_power))
 
    
    return energy_consumed, average_abs_mechanical_power, std_mechanical_power, covered_distance


class Integral:
    def __init__(self, sample_time, initial_value):
        self.sample_time = sample_time
        self.value = initial_value

    def integrate(self, new_value):
        self.value += new_value * self.sample_time
        return self.value
    
    def reset(self):
        self.value=0





import numpy as np
import time
import matplotlib.pyplot as plt

class Joints:  
    def __init__(self,p,RobotName,SampleTime,JointNames,JointHandles,HomeJointPositions,frame_duration):
        self.p=p
        self.RobotName=RobotName
        self.Joint_States={}
        self.JointNames=JointNames
        self.JointHandles=JointHandles
        self.SampleTime=SampleTime
        self.StartJointPositions=HomeJointPositions.copy() # if you write self.StartJointPositions=HomeJointPositions it will connect the variable !!!!!!!!1
        self.FinalJointPositions=HomeJointPositions.copy()
        self.Time=[]
        self.time=0
        self.frame_duration=frame_duration
        self.RefJointPositions={} # Here, for each joint, the reference position is stored
        self.MecPowers={} # Instantaneous Mechanical Power for all samples
        self.JointTrackingErrors={} #Instantaneous Joint Tracking Error 
        self.JointAverageErrors={}
          
        for JointName in self.JointNames:
            self.Joint_States[JointName]=[]
            self.RefJointPositions[JointName]=[]
            if JointName in self.JointHandles:
                self.p.enableJointForceTorqueSensor(self.RobotName, self.JointHandles[JointName], 1)
            else:
                print(f"Warning: Joint {JointName} not found!")
            self.MecPowers[JointName]=[]
            self.JointTrackingErrors[JointName]=[]
            self.JointAverageErrors[JointName]=0
    
    # The position is in deg        
    def SetJointPositions(self, Steps, JointPositions, ForceMax, PID): 
        # Calculate the AngleStep for each joint according to how much they need to move
        TotalDifferences = {JointName: JointPositions[JointName] - self.StartJointPositions[JointName] for JointName in self.JointNames}
        AngleStep = {JointName: TotalDifferences[JointName] / Steps for JointName in self.JointNames}

        for i in range(Steps):
            for JointName in self.JointNames:
                if (Steps==1):
                    RefPosition = JointPositions[JointName]
                else:    
                    RefPosition = self.StartJointPositions[JointName] + AngleStep[JointName]*i
                    
                self.RefJointPositions[JointName].append(RefPosition)
                self.p.setJointMotorControl2(self.RobotName, 
                                             self.JointHandles[JointName], 
                                             self.p.POSITION_CONTROL,
                                             targetPosition=np.deg2rad(RefPosition), 
                                             force=ForceMax,
                                             positionGain=PID[0],
                                             velocityGain=PID[2])
                # Get the Joint States
                # self.Joint_States[JointName].append(self.p.getJointState(self.RobotName,self.JointHandles[JointName]))

                # Replace the third element of the tuple with a dummy value (0.0)
                joint_state = self.p.getJointState(self.RobotName, self.JointHandles[JointName])
                modified_joint_state = (joint_state[0], joint_state[1], 0.0, joint_state[3])  # Replace third element
                self.Joint_States[JointName].append(modified_joint_state)

                self.FinalJointPositions[JointName]=RefPosition
            self.p.stepSimulation() 
            # Add a delay to match the real-time frame rate (Needed when you record videos)
            time.sleep(self.frame_duration)
            if (Steps==1):
                self.Time.append(self.time+self.SampleTime)
            else:    
                self.Time.append(self.time+self.SampleTime*i)
     
        self.StartJointPositions=self.FinalJointPositions.copy() # it copies only the values
        self.time=self.Time[len(self.Time)-1]
    
        return self.Joint_States
    
    def PlotJointTorques(self):
        fig, ax = plt.subplots()
        for JointName in self.JointNames:    
            ax.plot(self.Time, np.array(self.Joint_States[JointName])[:,3])
        ax.set_title(' ')
        ax.set_xlabel('Time [s]')
        ax.set_ylabel('Joint Torques [Nm]')
        plt.grid(visible=True)
        plt.legend(self.JointNames)
        fig.tight_layout()
        
    def PlotJointPositions(self):
        fig, ax = plt.subplots()
        for JointName in self.JointNames:    
            ax.plot(self.Time, np.rad2deg([float(i) for i in np.array(self.Joint_States[JointName])[:,0]]))
        ax.set_title(' ')
        ax.set_xlabel('Time [s]')
        ax.set_ylabel('Joint Positions [Deg]')
        plt.grid(visible=True)
        plt.legend(self.JointNames)
        fig.tight_layout()
    
    def PlotRefVsActJointPositions(self):
        fig, ax = plt.subplots()
        for JointName in self.JointNames:    
            ax.plot(self.Time, np.rad2deg([float(i) for i in np.array(self.Joint_States[JointName])[:,0]]))
        plt.legend(self.JointNames)    
        plt.gca().set_prop_cycle(None)
        for JointName in self.JointNames: 
            ax.plot(self.Time, np.array(self.RefJointPositions[JointName]), '--')
        ax.set_title(' ')
        ax.set_xlabel('Time [s]')
        ax.set_ylabel('Ref vs Real Joint Positions [Deg]')
        plt.grid(visible=True)
        fig.tight_layout()
    
    def CalculateJointTrackingErrors(self):
        for JointName in self.JointNames: 
            ActualJointPositions=np.rad2deg([float(i) for i in np.array(self.Joint_States[JointName])[:,0]])
            self.JointTrackingErrors[JointName]=np.array(self.RefJointPositions[JointName])-ActualJointPositions
            self.JointAverageErrors[JointName]=np.mean(np.abs(self.JointTrackingErrors[JointName]))
            TotMeanError=np.mean(self.JointAverageErrors[JointName])
        
        return TotMeanError,self.JointTrackingErrors  
                
    def PlotJointVelocities(self):
        fig, ax = plt.subplots()
        for JointName in self.JointNames: 
            ax.plot(self.Time, np.rad2deg([float(i) for i in np.array(self.Joint_States[JointName])[:,1]]))
        ax.set_title(' ')
        ax.set_xlabel('Time [s]')
        ax.set_ylabel('Joint Velocities [Deg/s]')
        plt.grid(visible=True)
        plt.legend(self.JointNames)
        fig.tight_layout()
        
    def EnergyConsumed(self):
        Integ = Integral(self.SampleTime, initial_value=0)
        TotEnergy = 0
        print("")
        for JointName in self.JointNames: 
            JointTotEnergy = 0
            Velocities = np.array(self.Joint_States[JointName])[:,1]
            Torques = np.array(self.Joint_States[JointName])[:,3]
            self.MecPowers[JointName] = np.multiply(np.abs(Velocities), np.abs(Torques)) 
            for I in range(len(self.MecPowers[JointName])):
                JointTotEnergy = Integ.integrate(self.MecPowers[JointName][I])    
            TotEnergy += JointTotEnergy # Sum up all joints' mechanical powers 
            Integ.reset()
            
        return TotEnergy
    
    def CalculateTorqueSmoothness(self):
        smoothness_indices = []
        for JointName in self.JointNames:
            torques = np.array(self.Joint_States[JointName])[:,3]
            if len(torques) > 1:
                torque_diff = np.diff(torques)
                std_diff = np.std(torque_diff)
                max_diff = np.max(np.abs(torque_diff))
                if max_diff != 0:
                    smoothness_index = 1 - (std_diff / max_diff)
                else:
                    smoothness_index = 1
            else:
                smoothness_index = 1
            smoothness_indices.append(smoothness_index)
        
        overall_smoothness = np.mean(smoothness_indices)
        return overall_smoothness


        
        
def capture_frame():
    width, height, rgb_img, depth_img, seg_img = p.getCameraImage(
        width=1280, height=800,
        renderer=p.ER_BULLET_HARDWARE_OPENGL
    )
    return rgb_img 

def Execute_Gate(rightFootPathData, leftFootPathData, NumberOfFullStepSequence,KneeBendDist, PLOT=False, Home=False, Lifted=False, AcquireFrames=False,SamplingFrameFrequency=100,physicsClient=1,PID=[0.2,0,1]):

   
        
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.8)
    SampleTime = 0.01 # seconds it must be the same in the PyBullet simulation
    p.setTimeStep(SampleTime,physicsClient)

    planeId = p.loadURDF("plane.urdf")
    startPos = [0, 0, 0]
    startOrientation = p.getQuaternionFromEuler([0, 0, 3.14])
    robot = p.loadURDF("nu_biped_final.urdf", startPos, startOrientation)
    
    p.resetDebugVisualizerCamera(cameraDistance=1.5, cameraYaw=90, cameraPitch=0, cameraTargetPosition=[0, -1.5, 0.8])    
    
    PrintMainFrame(p,robot)
    PrintMainFrame(p,planeId)

    if(AcquireFrames):
         # Start recording the video with the specified resolution
         log_id = p.startStateLogging(p.STATE_LOGGING_VIDEO_MP4, "./Videos/Biped.mp4")
         
    # JointHandle
    JointNames = [
        "RHipYaw", "RHipPitch", "RHipRoll", "RKnee", "RAnklePitch", "RAnkleRoll",
        "LHipYaw", "LHipPitch", "LHipRoll", "LKnee", "LAnklePitch", "LAnkleRoll"
    ]
    
    JointHandles = {
        "RHipYaw": 0, "RHipPitch": 1, "RHipRoll": 2, "RKnee": 3, "RAnklePitch": 4, "RAnkleRoll": 5,
        "LHipYaw": 6, "LHipPitch": 7, "LHipRoll": 8, "LKnee": 9, "LAnklePitch": 10, "LAnkleRoll": 11
    }
    
    HomeJointPositions = {
        "RHipYaw": 0, "RHipPitch": 0, "RHipRoll": 0, "RKnee": 0, "RAnklePitch": 0, "RAnkleRoll": 0,
        "LHipYaw": 0, "LHipPitch": 0, "LHipRoll": 0, "LKnee": 0, "LAnklePitch": 0, "LAnkleRoll": 0
    }

    
    # Set the desired frame rate (e.g., 240 FPS)
    frame_rate = 1/SampleTime # Matches the Sampling Frequency for video recording, set to zero for fast simulation
    frame_duration = 1.0 / frame_rate 
    FramesSequence=[]

    if (AcquireFrames):
        RobotJoints=Joints(p,robot,SampleTime,JointNames,JointHandles,HomeJointPositions,frame_duration)
    else:
        RobotJoints=Joints(p,robot,SampleTime,JointNames,JointHandles,HomeJointPositions,0)
        
    #PID=[0.2,0,1] # Tuned with the robot base fixed and rotated horizontally. 
    MaxTorque=50
    
    # Change friction of the plane (ground)
    p.changeDynamics(planeId, -1, lateralFriction=1, spinningFriction=1, rollingFriction=0.1)


   

    #[t11, t21, t31, t41, t51, t6, T11, T21, T31, T41, T51, T6]
    joint_indices = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

    
    # Real Robot Mesasuraments NU_Biped V4.5
    l1 = 0.166  #2*l2=0.33
    #l2 = 0.232  #2*l2=0.46
    l2 = 0.180
    l3 = 0.256 # NU-Biped_4.7 0.256
    l4 = 0.260
    l5 = 0.104
    l6 = 0.134
    
    
    # lz is the distance between the origin Frame-1 (hip) and the Foot-frame. Because the Cartesian reference trajectory is with respect to a frame with 
    # the origin between the two feet (with z=0) you need to sum to subtract from lz the z-coordinate
    
    #KneeBendDist=-0.07 # Now the robot is 0.1 meter shorter so 0.03 becoms -0.07, the higher (+) is this the more bended are the knees 
    #lz=l3+l4+l5+l6-0.01
    lz=l3+l4+l5+l6-KneeBendDist  
    



    initialPos, _ = p.getBasePositionAndOrientation(robot)

    RightFootPose, LeftFootPose = ReadSample(0, rightFootPathData, leftFootPathData)
    ux, uy, uz, vx, vy, vz, wx, wy, wz, px, py, pz = RightFootPose
    ux2, uy2, uz2, vx2, vy2, vz2, wx2, wy2, wz2, px2, py2, pz2 = LeftFootPose
    
    
    Range = 240

    Rt11, Rt21, Rt31, Rt41, Rt51, Rt6 = ik_method(px, py + l2, lz - pz, ux, uy, uz, vx, vy, vz, wx, wy, wz) / Range
    RT11, RT21, RT31, RT41, RT51, RT6 = ik_method(px2, py2 - l2, lz - pz2, ux2, uy2, uz2, vx2, vy2, vz2, wx2, wy2, wz2) / Range

    Time = []

    for i in range(Range):
        t14, t21, t31, t41, t51, t6 = Rt11 * i, Rt21 * i, Rt31 * i, Rt41 * i * i / Range, Rt51 * i * i / Range, Rt6 * i
        T14, T21, T31, T41, T51, T6 = RT11 * i, RT21 * i, RT31 * i, RT41 * i * i / Range, RT51 * i * i / Range, RT6 * i

        if Home:
            t11, t21, t31, t41, t51, t6 = [0, 0, 0, 0, 0, 0]
            T11, T21, T31, T41, T51, T6 = [0, 0, 0, 0, 0, 0]
            JointPositions={"LHipYaw":0,"LHipPitch":0,"LHipRoll":0,"LKnee":0,"LAnklePitch":0,"LAnkleRoll":0,"RHipYaw":0,"RHipPitch":0,"RHipRoll":0,"RKnee":0,"RAnklePitch":0,"RAnkleRoll":0}
            #SendJointPositions(joint_indices, [t11, t21, t31, t41, t51, t6, T11, T21, T31, T41, T51, T6],RealTime,SampleTime)
            RobotJoints.SetJointPositions(1,JointPositions,MaxTorque,PID)
        else:
            JointPositions={"LHipYaw":T14,"LHipPitch":T21,"LHipRoll":T31,"LKnee":T41,"LAnklePitch":T51,"LAnkleRoll":T6,"RHipYaw":t14,"RHipPitch":t21,"RHipRoll":t31,"RKnee":t41,"RAnklePitch":t51,"RAnkleRoll":t6}
            #SendJointPositions(joint_indices, [t11, t21, t31, t41, t51, t6, T11, T21, T31, T41, T51, T6],RealTime,SampleTime)
            RobotJoints.SetJointPositions(1,JointPositions,MaxTorque,PID)
       

    time.sleep(0.3)

    CoveredDistance = []
    FullStepSequenceIterations = NumberOfFullStepSequence
    print("RealTime=", FullStepSequenceIterations , "s")


    SimJointPositions = []
    SimJointVelocities = []
    SimJointTorques = []
    
    SamplingFrameTime=0


    for ii in range(FullStepSequenceIterations):
        start_time = time.time()
        initialPos, _ = p.getBasePositionAndOrientation(robot)
        

        for i in range(int(len(leftFootPathData) / 7)):
            
            SamplingFrameTime=SamplingFrameTime+1
            
            RightFootPose, LeftFootPose = ReadSample(i, rightFootPathData, leftFootPathData)
            ux, uy, uz, vx, vy, vz, wx, wy, wz, px, py, pz = RightFootPose
            ux2, uy2, uz2, vx2, vy2, vz2, wx2, wy2, wz2, px2, py2, pz2 = LeftFootPose

      
            t11, t21, t31, t41, t51, t6 = ik_method(px, l2+py, (lz - pz), ux, uy, uz, vx, vy, vz, wx, wy, wz,Print=False) # Right Leg 
            T11, T21, T31, T41, T51, T6 = ik_method(px2, -l2+py2, (lz - pz2),  ux2, uy2, uz2, vx2, vy2, vz2, wx2, wy2, wz2,Print=False) # Left Leg
            
                        
            JointPositions={"LHipYaw":T11,"LHipPitch":T21,"LHipRoll":T31,"LKnee":T41,"LAnklePitch":T51,"LAnkleRoll":T6,"RHipYaw":t14,"RHipPitch":t21,"RHipRoll":t31,"RKnee":t41,"RAnklePitch":t51,"RAnkleRoll":t6}
            RobotJoints.SetJointPositions(1,JointPositions,MaxTorque,PID)
            
            #SendJointPositions(joint_indices, [t11, t21, t31, t41, t51, t6, T11, T21, T31, T41, T51, T6],RealTime,SampleTime)



            pos, orn = p.getBasePositionAndOrientation(robot)
            comPos = pos
            CoveredDistance.append(pos[0])

            # Checks if the robot fell down
            GaitSuccess = True
            if not Lifted:
                if comPos[2] < 0.79:  # Adjust the threshold as needed
                    print("----------->Fell Down!!")
                    GaitSuccess = False
                    break
            

             # Capture joint positions and torques
            joint_states = p.getJointStates(robot, joint_indices)
            joint_positions = [state[0] for state in joint_states] # radiants
            joint_velocities=[state[1] for state in joint_states] # radiants/s
            joint_torques = [state[3] for state in joint_states]  #Nm
    
            SimJointPositions.append(joint_positions)
            SimJointVelocities.append(joint_velocities)
            SimJointTorques.append(joint_torques)
            
 
            if ((AcquireFrames)and(SamplingFrameTime==SamplingFrameFrequency)):
                FramesSequence.append(capture_frame())
                SamplingFrameTime=0
            
       # printProgressBar(ii, FullStepSequenceIterations, prefix='Execution Progress:', suffix='Complete', length=50)
    
    end_time = time.time()
    Time.append(end_time - start_time)

    #     When the step sequence is finished 

    if GaitSuccess:
           energy_consumed_GPT, average_abs_mechanical_power, std_mechanical_power, covered_distance=Calculate_mechanical_power_energy(robot, startPos, SimJointPositions,SimJointVelocities, SimJointTorques, SampleTime, NumberOfFullStepSequence, leftFootPathData)
           energy_consumed_MFX=RobotJoints.EnergyConsumed()
    else:
           covered_distance=0
           energy_consumed_GPT=0
           average_abs_mechanical_power=0
           std_mechanical_power=0
           energy_consumed_MFX=0
    
    #p.disconnect()
    if(AcquireFrames):
        p.stopStateLogging(p.STATE_LOGGING_VIDEO_MP4)
        
        
    p.resetSimulation()
        
        
    if PLOT:
        RobotJoints.PlotJointTorques()
        RobotJoints.PlotJointPositions()
        RobotJoints.PlotRefVsActJointPositions()
        RobotJoints.PlotJointVelocities()

    print("Energy Consumed MFX =", energy_consumed_MFX," [J]" )
    print("Energy Consumed GPT =",energy_consumed_GPT," [J]" )
    
    TotJointsMeanError, JointTrackingErrors=RobotJoints.CalculateJointTrackingErrors()
   
    return GaitSuccess,covered_distance,energy_consumed_MFX,average_abs_mechanical_power,std_mechanical_power,FramesSequence,  RobotJoints.CalculateTorqueSmoothness(), TotJointsMeanError, JointTrackingErrors
